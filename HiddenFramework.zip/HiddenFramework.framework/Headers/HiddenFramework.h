//
//  HiddenFramework.h
//  HiddenFramework
//
//  Created by Gin on 08/12/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for HiddenFramework.
FOUNDATION_EXPORT double HiddenFrameworkVersionNumber;

//! Project version string for HiddenFramework.
FOUNDATION_EXPORT const unsigned char HiddenFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HiddenFramework/PublicHeader.h>


